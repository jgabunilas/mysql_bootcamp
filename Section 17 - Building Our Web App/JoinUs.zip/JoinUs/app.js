var express = require('express');
var app = express();
var mysql = require('mysql');
var bodyParser = require("body-parser");

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(__dirname + "/public"));

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  database : 'join_us'
});

app.get("/", function(req, res) {
	// console.log("SOMEONE REQUESTED US!")
	// res.send("You've Reached the Home Page!")
	// Build the query variable. Note that the variable that you use as an alias must match the variable used to pull the result from the results below
	var q = "SELECT COUNT(*) AS count FROM users";
	// Build the connection
	connection.query(q, function(err, results) {
		if (err) throw err;
		// 	Pull the count results. Be sure the alias matches
		var count = results[0].count;
		// res.send("We have " + count + " users in our database.");
		res.render("home", {data: count});
	});
	
	
});

app.post("/register", function(req, res){
	// console.log(req.body)
	// console.log("POST REQEST SENT TO /REGISTER email is " + req.body.email);
	var person = {
		email: req.body.email
	}
	connection.query('INSERT INTO users SET ?', person, function(err, result) {
		if (err) throw err;
		// console.log(result)
		// res.send("Thanks for joining our wait list!")
		res.redirect("/");
	});
});

app.get("/joke", function(req, res) {
	var joke = "<strong>What do you call a dog that does magic tricks?</strong> <em>A labracadabrador!</em>";
	// console.log("Requested the joke route!");
	res.send(joke);
});

app.get("/random_num", function(req, res){
    var num = Math.floor((Math.random() * 10) + 1);
    res.send("Your lucky number is " + num);
});

app.listen(3000, function() {
	console.log('App listening on port 3000!');
});

